# FIXED

driverlib/epi.obj: ../driverlib/epi.c
driverlib/epi.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/rom.h
driverlib/epi.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stdbool.h
driverlib/epi.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/_ti_config.h
driverlib/epi.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/linkage.h
driverlib/epi.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stdint.h
driverlib/epi.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/_stdint40.h
driverlib/epi.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/stdint.h
driverlib/epi.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/cdefs.h
driverlib/epi.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/_types.h
driverlib/epi.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/machine/_types.h
driverlib/epi.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/machine/_stdint.h
driverlib/epi.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/_stdint.h
driverlib/epi.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_epi.h
driverlib/epi.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_ints.h
driverlib/epi.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_memmap.h
driverlib/epi.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_sysctl.h
driverlib/epi.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_types.h
driverlib/epi.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/debug.h
driverlib/epi.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/epi.h
driverlib/epi.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/interrupt.h

../driverlib/epi.c:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/rom.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stdbool.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/_ti_config.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/linkage.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stdint.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/_stdint40.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/stdint.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/cdefs.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/_types.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/machine/_types.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/machine/_stdint.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/_stdint.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_epi.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_ints.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_memmap.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_sysctl.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_types.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/debug.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/epi.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/interrupt.h:

