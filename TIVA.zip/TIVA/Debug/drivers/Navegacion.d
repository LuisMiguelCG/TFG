# FIXED

drivers/Navegacion.obj: ../drivers/Navegacion.c
drivers/Navegacion.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/rom.h
drivers/Navegacion.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/drivers/Navegacion.h
drivers/Navegacion.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/Tiva_common.h
drivers/Navegacion.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stdbool.h
drivers/Navegacion.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/_ti_config.h
drivers/Navegacion.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/linkage.h
drivers/Navegacion.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stdint.h
drivers/Navegacion.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/_stdint40.h
drivers/Navegacion.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/stdint.h
drivers/Navegacion.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/cdefs.h
drivers/Navegacion.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/_types.h
drivers/Navegacion.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/machine/_types.h
drivers/Navegacion.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/machine/_stdint.h
drivers/Navegacion.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/_stdint.h
drivers/Navegacion.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stdio.h
drivers/Navegacion.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stdarg.h
drivers/Navegacion.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/string.h
drivers/Navegacion.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/xlocale/_string.h
drivers/Navegacion.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/math.h
drivers/Navegacion.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/_defs.h
drivers/Navegacion.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/machine/_limits.h
drivers/Navegacion.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_types.h
drivers/Navegacion.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_memmap.h
drivers/Navegacion.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_ints.h
drivers/Navegacion.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_uart.h
drivers/Navegacion.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_adc.h
drivers/Navegacion.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_i2c.h
drivers/Navegacion.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/pin_map.h
drivers/Navegacion.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/rom_map.h
drivers/Navegacion.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/sysctl.h
drivers/Navegacion.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/gpio.h
drivers/Navegacion.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/buttons.h
drivers/Navegacion.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/interrupt.h
drivers/Navegacion.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/pwm.h
drivers/Navegacion.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/adc.h
drivers/Navegacion.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/timer.h
drivers/Navegacion.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/uart.h
drivers/Navegacion.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/i2c.h
drivers/Navegacion.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/utils/cpu_usage.h
drivers/Navegacion.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/utils/uartstdio.h
drivers/Navegacion.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/FreeRTOS.h
drivers/Navegacion.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stddef.h
drivers/Navegacion.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/FreeRTOSConfig.h
drivers/Navegacion.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/utils/RunTimeStatsConfig.h
drivers/Navegacion.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/projdefs.h
drivers/Navegacion.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/portable.h
drivers/Navegacion.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/deprecated_definitions.h
drivers/Navegacion.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/portable/CCS/ARM_CM4F/portmacro.h
drivers/Navegacion.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/mpu_wrappers.h
drivers/Navegacion.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/semphr.h
drivers/Navegacion.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/queue.h
drivers/Navegacion.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/task.h
drivers/Navegacion.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/list.h
drivers/Navegacion.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/drivers/SenDistancia.h
drivers/Navegacion.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/drivers/Motor.h
drivers/Navegacion.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/drivers/Brujula.h
drivers/Navegacion.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/drivers/ComI2C.h
drivers/Navegacion.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/drivers/Navegacion.h
drivers/Navegacion.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/drivers/ComUART.h

../drivers/Navegacion.c:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/rom.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/drivers/Navegacion.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/Tiva_common.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stdbool.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/_ti_config.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/linkage.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stdint.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/_stdint40.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/stdint.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/cdefs.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/_types.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/machine/_types.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/machine/_stdint.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/_stdint.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stdio.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stdarg.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/string.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/xlocale/_string.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/math.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/_defs.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/machine/_limits.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_types.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_memmap.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_ints.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_uart.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_adc.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_i2c.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/pin_map.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/rom_map.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/sysctl.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/gpio.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/buttons.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/interrupt.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/pwm.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/adc.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/timer.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/uart.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/i2c.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/utils/cpu_usage.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/utils/uartstdio.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/FreeRTOS.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stddef.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/FreeRTOSConfig.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/utils/RunTimeStatsConfig.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/projdefs.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/portable.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/deprecated_definitions.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/portable/CCS/ARM_CM4F/portmacro.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/mpu_wrappers.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/semphr.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/queue.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/task.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/list.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/drivers/SenDistancia.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/drivers/Motor.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/drivers/Brujula.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/drivers/ComI2C.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/drivers/Navegacion.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/drivers/ComUART.h:

