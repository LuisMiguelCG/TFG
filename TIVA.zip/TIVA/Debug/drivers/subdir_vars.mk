################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../drivers/Brujula.c \
../drivers/ComI2C.c \
../drivers/ComUART.c \
../drivers/Motor.c \
../drivers/Navegacion.c \
../drivers/SenDistancia.c 

C_DEPS += \
./drivers/Brujula.d \
./drivers/ComI2C.d \
./drivers/ComUART.d \
./drivers/Motor.d \
./drivers/Navegacion.d \
./drivers/SenDistancia.d 

OBJS += \
./drivers/Brujula.obj \
./drivers/ComI2C.obj \
./drivers/ComUART.obj \
./drivers/Motor.obj \
./drivers/Navegacion.obj \
./drivers/SenDistancia.obj 

OBJS__QUOTED += \
"drivers\Brujula.obj" \
"drivers\ComI2C.obj" \
"drivers\ComUART.obj" \
"drivers\Motor.obj" \
"drivers\Navegacion.obj" \
"drivers\SenDistancia.obj" 

C_DEPS__QUOTED += \
"drivers\Brujula.d" \
"drivers\ComI2C.d" \
"drivers\ComUART.d" \
"drivers\Motor.d" \
"drivers\Navegacion.d" \
"drivers\SenDistancia.d" 

C_SRCS__QUOTED += \
"../drivers/Brujula.c" \
"../drivers/ComI2C.c" \
"../drivers/ComUART.c" \
"../drivers/Motor.c" \
"../drivers/Navegacion.c" \
"../drivers/SenDistancia.c" 


