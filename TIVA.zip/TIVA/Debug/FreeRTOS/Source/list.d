# FIXED

FreeRTOS/Source/list.obj: ../FreeRTOS/Source/list.c
FreeRTOS/Source/list.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/rom.h
FreeRTOS/Source/list.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stdlib.h
FreeRTOS/Source/list.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/_ti_config.h
FreeRTOS/Source/list.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/linkage.h
FreeRTOS/Source/list.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/cdefs.h
FreeRTOS/Source/list.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/FreeRTOS.h
FreeRTOS/Source/list.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stddef.h
FreeRTOS/Source/list.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stdint.h
FreeRTOS/Source/list.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/_stdint40.h
FreeRTOS/Source/list.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/stdint.h
FreeRTOS/Source/list.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/_types.h
FreeRTOS/Source/list.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/machine/_types.h
FreeRTOS/Source/list.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/machine/_stdint.h
FreeRTOS/Source/list.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/_stdint.h
FreeRTOS/Source/list.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/FreeRTOSConfig.h
FreeRTOS/Source/list.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_memmap.h
FreeRTOS/Source/list.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_types.h
FreeRTOS/Source/list.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_ints.h
FreeRTOS/Source/list.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/pin_map.h
FreeRTOS/Source/list.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/rom_map.h
FreeRTOS/Source/list.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/utils/RunTimeStatsConfig.h
FreeRTOS/Source/list.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stdbool.h
FreeRTOS/Source/list.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/projdefs.h
FreeRTOS/Source/list.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/portable.h
FreeRTOS/Source/list.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/deprecated_definitions.h
FreeRTOS/Source/list.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/portable/CCS/ARM_CM4F/portmacro.h
FreeRTOS/Source/list.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/mpu_wrappers.h
FreeRTOS/Source/list.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/list.h

../FreeRTOS/Source/list.c:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/rom.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stdlib.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/_ti_config.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/linkage.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/cdefs.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/FreeRTOS.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stddef.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stdint.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/_stdint40.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/stdint.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/_types.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/machine/_types.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/machine/_stdint.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/_stdint.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/FreeRTOSConfig.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_memmap.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_types.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_ints.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/pin_map.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/rom_map.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/utils/RunTimeStatsConfig.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stdbool.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/projdefs.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/portable.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/deprecated_definitions.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/portable/CCS/ARM_CM4F/portmacro.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/mpu_wrappers.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/list.h:

