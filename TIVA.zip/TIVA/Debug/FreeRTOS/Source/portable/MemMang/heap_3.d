# FIXED

FreeRTOS/Source/portable/MemMang/heap_3.obj: ../FreeRTOS/Source/portable/MemMang/heap_3.c
FreeRTOS/Source/portable/MemMang/heap_3.obj: C:/TIVA/WorkSpace/Tiva2/driverlib/rom.h
FreeRTOS/Source/portable/MemMang/heap_3.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stdlib.h
FreeRTOS/Source/portable/MemMang/heap_3.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/_ti_config.h
FreeRTOS/Source/portable/MemMang/heap_3.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/linkage.h
FreeRTOS/Source/portable/MemMang/heap_3.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/cdefs.h
FreeRTOS/Source/portable/MemMang/heap_3.obj: C:/TIVA/WorkSpace/Tiva2/FreeRTOS/Source/include/FreeRTOS.h
FreeRTOS/Source/portable/MemMang/heap_3.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stddef.h
FreeRTOS/Source/portable/MemMang/heap_3.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stdint.h
FreeRTOS/Source/portable/MemMang/heap_3.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/_stdint40.h
FreeRTOS/Source/portable/MemMang/heap_3.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/stdint.h
FreeRTOS/Source/portable/MemMang/heap_3.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/_types.h
FreeRTOS/Source/portable/MemMang/heap_3.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/machine/_types.h
FreeRTOS/Source/portable/MemMang/heap_3.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/machine/_stdint.h
FreeRTOS/Source/portable/MemMang/heap_3.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/_stdint.h
FreeRTOS/Source/portable/MemMang/heap_3.obj: C:/TIVA/WorkSpace/Tiva2/FreeRTOS/Source/include/FreeRTOSConfig.h
FreeRTOS/Source/portable/MemMang/heap_3.obj: C:/TIVA/WorkSpace/Tiva2/inc/hw_memmap.h
FreeRTOS/Source/portable/MemMang/heap_3.obj: C:/TIVA/WorkSpace/Tiva2/inc/hw_types.h
FreeRTOS/Source/portable/MemMang/heap_3.obj: C:/TIVA/WorkSpace/Tiva2/inc/hw_ints.h
FreeRTOS/Source/portable/MemMang/heap_3.obj: C:/TIVA/WorkSpace/Tiva2/driverlib/pin_map.h
FreeRTOS/Source/portable/MemMang/heap_3.obj: C:/TIVA/WorkSpace/Tiva2/driverlib/rom_map.h
FreeRTOS/Source/portable/MemMang/heap_3.obj: C:/TIVA/WorkSpace/Tiva2/utils/RunTimeStatsConfig.h
FreeRTOS/Source/portable/MemMang/heap_3.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stdbool.h
FreeRTOS/Source/portable/MemMang/heap_3.obj: C:/TIVA/WorkSpace/Tiva2/FreeRTOS/Source/include/projdefs.h
FreeRTOS/Source/portable/MemMang/heap_3.obj: C:/TIVA/WorkSpace/Tiva2/FreeRTOS/Source/include/portable.h
FreeRTOS/Source/portable/MemMang/heap_3.obj: C:/TIVA/WorkSpace/Tiva2/FreeRTOS/Source/include/deprecated_definitions.h
FreeRTOS/Source/portable/MemMang/heap_3.obj: C:/TIVA/WorkSpace/Tiva2/FreeRTOS/Source/portable/CCS/ARM_CM4F/portmacro.h
FreeRTOS/Source/portable/MemMang/heap_3.obj: C:/TIVA/WorkSpace/Tiva2/FreeRTOS/Source/include/mpu_wrappers.h
FreeRTOS/Source/portable/MemMang/heap_3.obj: C:/TIVA/WorkSpace/Tiva2/FreeRTOS/Source/include/task.h
FreeRTOS/Source/portable/MemMang/heap_3.obj: C:/TIVA/WorkSpace/Tiva2/FreeRTOS/Source/include/list.h

../FreeRTOS/Source/portable/MemMang/heap_3.c:

C:/TIVA/WorkSpace/Tiva2/driverlib/rom.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stdlib.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/_ti_config.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/linkage.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/cdefs.h:

C:/TIVA/WorkSpace/Tiva2/FreeRTOS/Source/include/FreeRTOS.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stddef.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stdint.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/_stdint40.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/stdint.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/_types.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/machine/_types.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/machine/_stdint.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/_stdint.h:

C:/TIVA/WorkSpace/Tiva2/FreeRTOS/Source/include/FreeRTOSConfig.h:

C:/TIVA/WorkSpace/Tiva2/inc/hw_memmap.h:

C:/TIVA/WorkSpace/Tiva2/inc/hw_types.h:

C:/TIVA/WorkSpace/Tiva2/inc/hw_ints.h:

C:/TIVA/WorkSpace/Tiva2/driverlib/pin_map.h:

C:/TIVA/WorkSpace/Tiva2/driverlib/rom_map.h:

C:/TIVA/WorkSpace/Tiva2/utils/RunTimeStatsConfig.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stdbool.h:

C:/TIVA/WorkSpace/Tiva2/FreeRTOS/Source/include/projdefs.h:

C:/TIVA/WorkSpace/Tiva2/FreeRTOS/Source/include/portable.h:

C:/TIVA/WorkSpace/Tiva2/FreeRTOS/Source/include/deprecated_definitions.h:

C:/TIVA/WorkSpace/Tiva2/FreeRTOS/Source/portable/CCS/ARM_CM4F/portmacro.h:

C:/TIVA/WorkSpace/Tiva2/FreeRTOS/Source/include/mpu_wrappers.h:

C:/TIVA/WorkSpace/Tiva2/FreeRTOS/Source/include/task.h:

C:/TIVA/WorkSpace/Tiva2/FreeRTOS/Source/include/list.h:

