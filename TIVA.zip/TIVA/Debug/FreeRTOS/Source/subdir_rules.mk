################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
FreeRTOS/Source/%.obj: ../FreeRTOS/Source/%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: Arm Compiler'
	"C:/Program Files (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/bin/armcl" -mv7M4 --code_state=16 --float_support=FPv4SPD16 -me --include_path="C:/Users/Luis Miguel/Desktop/WorkSpace_basura/TIVA" --include_path="C:/Program Files (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include" --include_path="C:/Users/Luis Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include" --include_path="C:/Users/Luis Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/portable/CCS/ARM_CM4F" --preinclude="C:/Users/Luis Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/rom.h" --define=ccs="ccs" --define=PART_TM4C123GH6PM --define=WANT_CMDLINE_HISTORY -g --gcc --diag_warning=225 --diag_wrap=off --display_error_number --abi=eabi --preproc_with_compile --preproc_dependency="FreeRTOS/Source/$(basename $(<F)).d_raw" --obj_directory="FreeRTOS/Source" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: "$<"'
	@echo ' '


