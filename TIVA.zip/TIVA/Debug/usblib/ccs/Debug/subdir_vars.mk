################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
LIB_SRCS += \
../usblib/ccs/Debug/usblib.lib 


