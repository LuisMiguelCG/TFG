# FIXED

utils/isqrt.obj: ../utils/isqrt.c
utils/isqrt.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/rom.h
utils/isqrt.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stdint.h
utils/isqrt.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/_ti_config.h
utils/isqrt.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/linkage.h
utils/isqrt.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/_stdint40.h
utils/isqrt.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/stdint.h
utils/isqrt.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/cdefs.h
utils/isqrt.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/_types.h
utils/isqrt.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/machine/_types.h
utils/isqrt.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/machine/_stdint.h
utils/isqrt.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/_stdint.h
utils/isqrt.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/utils/isqrt.h

../utils/isqrt.c:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/rom.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stdint.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/_ti_config.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/linkage.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/_stdint40.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/stdint.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/cdefs.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/_types.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/machine/_types.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/machine/_stdint.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/_stdint.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/utils/isqrt.h:

