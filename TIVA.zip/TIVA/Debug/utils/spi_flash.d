# FIXED

utils/spi_flash.obj: ../utils/spi_flash.c
utils/spi_flash.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/rom.h
utils/spi_flash.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stdint.h
utils/spi_flash.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/_ti_config.h
utils/spi_flash.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/linkage.h
utils/spi_flash.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/_stdint40.h
utils/spi_flash.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/stdint.h
utils/spi_flash.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/cdefs.h
utils/spi_flash.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/_types.h
utils/spi_flash.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/machine/_types.h
utils/spi_flash.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/machine/_stdint.h
utils/spi_flash.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/_stdint.h
utils/spi_flash.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stdbool.h
utils/spi_flash.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_ssi.h
utils/spi_flash.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_types.h
utils/spi_flash.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_udma.h
utils/spi_flash.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/rom_map.h
utils/spi_flash.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/ssi.h
utils/spi_flash.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/udma.h
utils/spi_flash.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/utils/spi_flash.h

../utils/spi_flash.c:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/rom.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stdint.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/_ti_config.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/linkage.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/_stdint40.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/stdint.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/cdefs.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/_types.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/machine/_types.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/machine/_stdint.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/_stdint.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stdbool.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_ssi.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_types.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_udma.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/rom_map.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/ssi.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/udma.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/utils/spi_flash.h:

