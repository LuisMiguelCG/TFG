# FIXED

utils/uartstdio.obj: ../utils/uartstdio.c
utils/uartstdio.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/rom.h
utils/uartstdio.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stdarg.h
utils/uartstdio.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/_types.h
utils/uartstdio.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/cdefs.h
utils/uartstdio.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/_ti_config.h
utils/uartstdio.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/linkage.h
utils/uartstdio.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/machine/_types.h
utils/uartstdio.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stdbool.h
utils/uartstdio.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stdint.h
utils/uartstdio.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/_stdint40.h
utils/uartstdio.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/stdint.h
utils/uartstdio.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/machine/_stdint.h
utils/uartstdio.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/_stdint.h
utils/uartstdio.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/FreeRTOS.h
utils/uartstdio.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stddef.h
utils/uartstdio.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/FreeRTOSConfig.h
utils/uartstdio.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_memmap.h
utils/uartstdio.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_types.h
utils/uartstdio.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_ints.h
utils/uartstdio.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/pin_map.h
utils/uartstdio.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/rom_map.h
utils/uartstdio.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/utils/RunTimeStatsConfig.h
utils/uartstdio.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/projdefs.h
utils/uartstdio.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/portable.h
utils/uartstdio.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/deprecated_definitions.h
utils/uartstdio.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/portable/CCS/ARM_CM4F/portmacro.h
utils/uartstdio.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/mpu_wrappers.h
utils/uartstdio.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/task.h
utils/uartstdio.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/list.h
utils/uartstdio.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/queue.h
utils/uartstdio.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/semphr.h
utils/uartstdio.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_uart.h
utils/uartstdio.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/debug.h
utils/uartstdio.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/interrupt.h
utils/uartstdio.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/sysctl.h
utils/uartstdio.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/uart.h
utils/uartstdio.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/utils/uartstdio.h

../utils/uartstdio.c:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/rom.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stdarg.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/_types.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/cdefs.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/_ti_config.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/linkage.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/machine/_types.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stdbool.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stdint.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/_stdint40.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/stdint.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/machine/_stdint.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/_stdint.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/FreeRTOS.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stddef.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/FreeRTOSConfig.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_memmap.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_types.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_ints.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/pin_map.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/rom_map.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/utils/RunTimeStatsConfig.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/projdefs.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/portable.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/deprecated_definitions.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/portable/CCS/ARM_CM4F/portmacro.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/mpu_wrappers.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/task.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/list.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/queue.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/semphr.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_uart.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/debug.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/interrupt.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/sysctl.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/uart.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/utils/uartstdio.h:

