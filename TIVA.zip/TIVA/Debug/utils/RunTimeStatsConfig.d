# FIXED

utils/RunTimeStatsConfig.obj: ../utils/RunTimeStatsConfig.c
utils/RunTimeStatsConfig.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/rom.h
utils/RunTimeStatsConfig.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stdbool.h
utils/RunTimeStatsConfig.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/_ti_config.h
utils/RunTimeStatsConfig.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/linkage.h
utils/RunTimeStatsConfig.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stdint.h
utils/RunTimeStatsConfig.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/_stdint40.h
utils/RunTimeStatsConfig.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/stdint.h
utils/RunTimeStatsConfig.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/cdefs.h
utils/RunTimeStatsConfig.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/_types.h
utils/RunTimeStatsConfig.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/machine/_types.h
utils/RunTimeStatsConfig.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/machine/_stdint.h
utils/RunTimeStatsConfig.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/_stdint.h
utils/RunTimeStatsConfig.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stdio.h
utils/RunTimeStatsConfig.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stdarg.h
utils/RunTimeStatsConfig.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/string.h
utils/RunTimeStatsConfig.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/xlocale/_string.h
utils/RunTimeStatsConfig.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/FreeRTOS.h
utils/RunTimeStatsConfig.obj: C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stddef.h
utils/RunTimeStatsConfig.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/FreeRTOSConfig.h
utils/RunTimeStatsConfig.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_memmap.h
utils/RunTimeStatsConfig.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_types.h
utils/RunTimeStatsConfig.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_ints.h
utils/RunTimeStatsConfig.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/pin_map.h
utils/RunTimeStatsConfig.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/rom_map.h
utils/RunTimeStatsConfig.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/utils/RunTimeStatsConfig.h
utils/RunTimeStatsConfig.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/projdefs.h
utils/RunTimeStatsConfig.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/portable.h
utils/RunTimeStatsConfig.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/deprecated_definitions.h
utils/RunTimeStatsConfig.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/portable/CCS/ARM_CM4F/portmacro.h
utils/RunTimeStatsConfig.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/mpu_wrappers.h
utils/RunTimeStatsConfig.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/task.h
utils/RunTimeStatsConfig.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/list.h
utils/RunTimeStatsConfig.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/debug.h
utils/RunTimeStatsConfig.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/sysctl.h
utils/RunTimeStatsConfig.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/timer.h
utils/RunTimeStatsConfig.obj: C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/utils/cpu_usage.h

../utils/RunTimeStatsConfig.c:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/rom.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stdbool.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/_ti_config.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/linkage.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stdint.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/_stdint40.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/stdint.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/cdefs.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/_types.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/machine/_types.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/machine/_stdint.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/sys/_stdint.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stdio.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stdarg.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/string.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/xlocale/_string.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/FreeRTOS.h:

C:/Program\ Files\ (x86)/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include/stddef.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/FreeRTOSConfig.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_memmap.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_types.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/inc/hw_ints.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/pin_map.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/rom_map.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/utils/RunTimeStatsConfig.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/projdefs.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/portable.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/deprecated_definitions.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/portable/CCS/ARM_CM4F/portmacro.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/mpu_wrappers.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/task.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/FreeRTOS/Source/include/list.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/debug.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/sysctl.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/driverlib/timer.h:

C:/Users/Luis\ Miguel/Desktop/WorkSpace_basura/TIVA/utils/cpu_usage.h:

