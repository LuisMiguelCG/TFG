/**
 * Driver encagardo de gestionar la navegaci�n del robot en el laberinto.
 */

/*********************************************************************************
*  Includes
********************************************************************************/
#include "drivers/Navegacion.h"

/*********************************************************************************
* Variable Globales
********************************************************************************/
InfoPosicion_t posicion;
InfoPosicion_t mapa[MAPA_SIZE][MAPA_SIZE];
SemaphoreHandle_t SemaphoreNavegacion = NULL;
bool isFirstTime;
uint8_t girosI = 0;

extern rbt_modo_t MODO;
extern rbt_estado_t ESTADO;
extern rbt_estado_t ESTADO_ANT;
extern bool isReset;

/*********************************************************************************
 *  Funciones privadas
 ********************************************************************************/
static void intToStr(int num, char *str);

/*********************************************************************************
 *  Funciones
 ********************************************************************************/

/**
 * Funci�n para configurar el encoder y sensor bajo.
 * Inicializar el mapa y la posicion del robot en el mapa.
 */
void NavegacionInit()
{
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB);                            // Configuracion puerto GPIOB
    SysCtlPeripheralSleepEnable(SYSCTL_PERIPH_GPIOB);                       //
    IntPrioritySet(INT_GPIOB, configMAX_SYSCALL_INTERRUPT_PRIORITY);        //
    IntEnable(INT_GPIOB);                                                   //

    GPIODirModeSet(GPIO_PORTB_BASE, ENCODER_I , GPIO_DIR_MODE_IN);          // Configuracion sensor encoder
    GPIOPinTypeGPIOInput(GPIO_PORTB_BASE, ENCODER_I);                       //
    GPIOPadConfigSet(GPIO_PORTB_BASE, ENCODER_I,                            //
                     GPIO_STRENGTH_2MA, GPIO_PIN_TYPE_OD);                  //
    GPIOIntTypeSet(GPIO_PORTB_BASE, ENCODER_I, GPIO_BOTH_EDGES);            //
    GPIOIntEnable(GPIO_PORTB_BASE, ENCODER_I);                              //
    GPIOIntClear(GPIO_PORTB_BASE, ENCODER_I);                               //

    GPIODirModeSet(GPIO_PORTB_BASE, SENSOR_BAJO, GPIO_DIR_MODE_IN);         // Cnfiguracion sensor bajo
    GPIOPinTypeGPIOInput(GPIO_PORTB_BASE, SENSOR_BAJO);                     //
    GPIOPadConfigSet(GPIO_PORTB_BASE, SENSOR_BAJO,                          //
                     GPIO_STRENGTH_2MA, GPIO_PIN_TYPE_STD);                 //
    GPIOIntTypeSet(GPIO_PORTB_BASE, SENSOR_BAJO, GPIO_RISING_EDGE);         //
    GPIOIntEnable(GPIO_PORTB_BASE, SENSOR_BAJO);                            //
    GPIOIntClear(GPIO_PORTB_BASE, SENSOR_BAJO);                             //

    uint8_t i, j;

    for(i=0; i<MAPA_SIZE; ++i)
    {
        for(j=0; j<MAPA_SIZE; ++j)
        {
            mapa[i][j].estado = DESCONOCIDO;
        }
    }

    SemaphoreNavegacion = xSemaphoreCreateBinary();
    if(SemaphoreNavegacion == NULL) while(1);

    posicion.x = CENTRO;
    posicion.y = CENTRO;
    posicion.orientacion.eje = VERTICAL;
    posicion.orientacion.sentido = POSITIVO;

    isFirstTime = true;
    girosI = 0;

    OnOffEncoders(false);
}

/**
 * Funcion para resetar el mapa y restrablecer los valor de inicio.
 */
void ResetMapa()
{
    uint8_t i, j;

    for(i=0; i<MAPA_SIZE; ++i)
    {
        for(j=0; j<MAPA_SIZE; ++j)
        {
            mapa[i][j].estado = DESCONOCIDO;
        }
    }

    posicion.x = CENTRO;
    posicion.y = CENTRO;
    posicion.orientacion.eje = VERTICAL;
    posicion.orientacion.sentido = POSITIVO;

    isFirstTime = true;
    girosI = 0;
}



/**
 * Funcion para saber si la posicion actual del robot es conocida.
 */
bool PosicionConocida()
{
    int8_t x = posicion.x;
    int8_t y = posicion.y;

    return (mapa[x][y].estado != DESCONOCIDO) ? true : false;
}

/**
 * Funcion encargada de actulizar el mapa con la posicion del robot y la informacion recogida por este.
 */
void ActualizarMapa()
{
    int8_t x = posicion.x;
    int8_t y = posicion.y;

    posicion.paredes.f = ReadFrontal() ? PARED : NO_PARED;
    posicion.paredes.d = ReadDerecha() ? PARED : NO_PARED;
    posicion.paredes.i = ReadIzquierda() ? PARED : NO_PARED;

    bool soloUnCamino = (posicion.paredes.f == NO_PARED) + (posicion.paredes.i == NO_PARED) + (posicion.paredes.d == NO_PARED) == 1;
    bool sinSalida = (posicion.paredes.f == PARED && posicion.paredes.i == PARED && posicion.paredes.d == PARED);

    if (isFirstTime)
    {
        posicion.estado = soloUnCamino ? X : CONOCIDO;
    }
    else
    {
        if (sinSalida)
        {
            posicion.estado = X;
        }
        else if (soloUnCamino)
        {
            int8_t dx = (posicion.orientacion.eje == HORIZONTAL) ? (posicion.orientacion.sentido == POSITIVO ? -1 : 1) : 0;
            int8_t dy = (posicion.orientacion.eje == VERTICAL) ? (posicion.orientacion.sentido == POSITIVO ? -1 : 1) : 0;
            posicion.estado = (mapa[x + dx][y + dy].estado == X) ? X : CONOCIDO;
        }
        else
        {
            int8_t conteoX = (mapa[x][y-1].estado == X) + (mapa[x][y+1].estado == X) + (mapa[x+1][y].estado == X) +
                          (mapa[x-1][y].estado == X);
            posicion.estado = (conteoX >= 2) ? X : CONOCIDO;
        }
    }
    mapa[x][y] = posicion;
}

/**
 * Funcion encargada de decidir el proximo movimiento.
 */
void Decidir_Movimiento()
{
    int8_t x = posicion.x;
    int8_t y = posicion.y;

    int8_t dx = (posicion.orientacion.eje == HORIZONTAL) ? (posicion.orientacion.sentido == POSITIVO ? 1 : -1) : 0;
    int8_t dy = (posicion.orientacion.eje == VERTICAL) ? (posicion.orientacion.sentido == POSITIVO ? 1 : -1) : 0;

    bool sinSalida = (posicion.paredes.f == PARED && posicion.paredes.i == PARED && posicion.paredes.d == PARED);
    bool porFrente = (posicion.paredes.f == NO_PARED) && (mapa[x + dx][y + dy].estado != X);
    bool porDerecha = (posicion.paredes.d == NO_PARED) && ((posicion.orientacion.eje == HORIZONTAL) ? (mapa[x + dy][y - dx].estado != X) :
                                                                                                   (mapa[x + dy][y + dx].estado != X));

    bool porIzquierda = (posicion.paredes.i == NO_PARED) && ((posicion.orientacion.eje == HORIZONTAL) ? (mapa[x + dy][y + dx].estado != X) :
                                                                                                     (mapa[x - dy][y + dx].estado != X));

    if(sinSalida)
    {
        Brujula_Giro180();
        posicion.orientacion.sentido = (posicion.orientacion.sentido == POSITIVO) ? NEGATIVO : POSITIVO;

        if(MODO == IDLE || isReset)
        {
            ResetMapa();
            isReset = false;
            Parar();
            ESTADO_ANT = ESTADO;
            ESTADO = PARADO;
        }
        else
        {
            Avanzar();
            ESTADO_ANT = ESTADO;
            ESTADO = AVANZANDO;
        }

    }
    else if(porFrente)
    {
        if(MODO == IDLE || isReset)
        {
            ResetMapa();
            isReset = false;
            Parar();
            ESTADO_ANT = ESTADO;
            ESTADO = PARADO;
        }
        else
        {
            Avanzar();
            ESTADO_ANT = ESTADO;
            ESTADO = AVANZANDO;
        }

    }
    else if(porDerecha)
    {
        Brujula_Giro90(CMD_GIRO_90D);
        posicion.orientacion.sentido = (posicion.orientacion.eje == HORIZONTAL) ?
                                       (posicion.orientacion.sentido == POSITIVO ? NEGATIVO : POSITIVO) : posicion.orientacion.sentido;
        posicion.orientacion.eje = (posicion.orientacion.eje == HORIZONTAL) ? VERTICAL : HORIZONTAL;
        if(MODO == IDLE || isReset)
        {
            ResetMapa();
            isReset = false;
            Parar();
            ESTADO_ANT = ESTADO;
            ESTADO = PARADO;
        }
        else
        {
            Avanzar();
            ESTADO_ANT = ESTADO;
            ESTADO = AVANZANDO;
        }

    }
    else if(porIzquierda)
    {
        Brujula_Giro90(CMD_GIRO_90I);
        posicion.orientacion.sentido = (posicion.orientacion.eje == VERTICAL) ?
                                       (posicion.orientacion.sentido == POSITIVO ? NEGATIVO : POSITIVO) : posicion.orientacion.sentido;
        posicion.orientacion.eje = (posicion.orientacion.eje == HORIZONTAL) ? VERTICAL : HORIZONTAL;
        if(MODO == IDLE || isReset)
        {
            ResetMapa();
            isReset = false;
            Parar();
            ESTADO_ANT = ESTADO;
            ESTADO = PARADO;
        }
        else
        {
            Avanzar();
            ESTADO_ANT = ESTADO;
            ESTADO = AVANZANDO;
        }
    }
}

/**
 * Funcion encargada de actualizar la posicion del robot.
 */
void ActualizarPosicion()
{

    posicion.y += (posicion.orientacion.eje == VERTICAL) ? (posicion.orientacion.sentido == POSITIVO ? 1 : -1) : 0;
    posicion.x += (posicion.orientacion.eje == HORIZONTAL) ? (posicion.orientacion.sentido == POSITIVO ? 1 : -1) : 0;
}
/**
 * Tarea encargada de la navegacion del robot en el laberinto.
 */
void Navegacion_Task(void *pvParameters)
{
    while(1)
    {
        xSemaphoreTake(SemaphoreNavegacion, portMAX_DELAY);

        if(isFirstTime)
        {
            ActualizarMapa();
            Enviar_mensaje();
            Decidir_Movimiento();

            isFirstTime = false;
        }
        else
        {
            bool pc = PosicionConocida();
            ActualizarMapa();
            Enviar_mensaje();
            Decidir_Movimiento();
        }
    }
}

/**
 * Funcion encargada de construir y enviar el mensaje por la UART.
 *
 * Forma del mensaje : X.Y.R.L.F.S.E
 *
 * X: Coordenada X
 * Y: Coordenada Y
 * R: Pared Derecha
 * L: Pared Izquierda
 * F: Pared Frontal
 * S: Sentido Positivo/Negativo
 * E: Eje Vertical/Horizontal
 *
 */
void Enviar_mensaje()
{
    char mensaje[20] = "" , aux[3];

    // Coordenada X
    intToStr(posicion.x - CENTRO, aux);
    strcat(mensaje, aux);

    // Coordenada Y
    strcat(mensaje, ".");
    intToStr(posicion.y - CENTRO, aux);
    strcat(mensaje, aux);

    // Pared Derecha
    strcat(mensaje, ".");
    intToStr(posicion.paredes.d, aux);
    strcat(mensaje, aux);

    // Pared Izquierda
    strcat(mensaje, ".");
    intToStr(posicion.paredes.i, aux);
    strcat(mensaje, aux);

    // Pared Frontal
    strcat(mensaje, ".");
    intToStr(posicion.paredes.f, aux);
    strcat(mensaje, aux);


    // Sentido de Movimiento
    strcat(mensaje, ".");
    intToStr(posicion.orientacion.sentido, aux);
    strcat(mensaje, aux);

    // Eje de movimiento
    strcat(mensaje, ".");
    intToStr(posicion.orientacion.eje, aux);
    strcat(mensaje, aux);

    UART_SendData(UART2_BASE, (unsigned char*)mensaje, strlen(mensaje)+1);

}

/**
 * Funcion para habilitar o deshabilitar el encoder.
 */
void OnOffEncoders(bool on_off)
{
    if(on_off)
    {
        GPIOIntEnable(GPIO_PORTB_BASE, ENCODER_I);
        GPIOIntClear(GPIO_PORTB_BASE, ENCODER_I);
    }
    else
    {
        GPIOIntDisable(GPIO_PORTB_BASE, ENCODER_I);
        GPIOIntClear(GPIO_PORTB_BASE, ENCODER_I);
    }
}

/*********************************************************************************
 *  Funciones privadas
 ********************************************************************************/

/**
 * Funcion para convertir de tipo entero a cadena de caracteres.
 * Ej: 15 -> "15"
 */
 static void intToStr(int num, char *str) {
    int i = 0, j = 0, isNegative = 0;

    if (num == 0)
    {
        str[i++] = '0';
        str[i] = '\0';
        return;
    }

    if (num < 0)
    {
        isNegative = 1;
        num = -num;
    }

    // Extrae d�gitos en orden inverso
    while (num > 0)
    {
        str[i++] = '0' + (num % 10);
        num /= 10;
    }

    if (isNegative)
    {
        str[i++] = '-';
    }

    // Invertir la cadena
    for (j = 0; j < i / 2; j++)
    {
        char tmp = str[j];
        str[j] = str[i - 1 - j];
        str[i - 1 - j] = tmp;
    }
    str[i] = '\0';
}




/*********************************************************************************
 *  Rutinas de Interrupcion
 ********************************************************************************/
/**
 * Rutina encargada de las interruciones del encoder, sensor_bajo.
 */
void GPIOBIntHandle(void)
{
    BaseType_t xHigherPriorityTaskWoken = pdFALSE;
    uint32_t status = GPIOIntStatus(GPIO_PORTB_BASE, ENCODER_I|SENSOR_BAJO);

    if(status & ENCODER_I)
    {
        GPIOIntClear(GPIO_PORTB_BASE, ENCODER_I);
        girosI++;

        if(girosI == N_GIROS)
        {
            ActualizarPosicion();
            girosI = 0;
            xSemaphoreGiveFromISR(SemaphoreNavegacion, &xHigherPriorityTaskWoken);

        }
    }

    if(status & SENSOR_BAJO)
    {
        GPIOIntClear(GPIO_PORTB_BASE, SENSOR_BAJO);
        Parar();
        ResetMapa();
    }

    portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
}







