/*
 * Driver encargado de controlar los motores del robot
 */

/*********************************************************************************
 *  Includes
 ********************************************************************************/
#include "Tiva_common.h"
#include "drivers/Motor.h"

/*********************************************************************************
 * Variable Globales
 ********************************************************************************/
extern rbt_modo_t MODO;

/*********************************************************************************
 *  Funciones
 ********************************************************************************/

/**
 * Funci�n para configurar el modulo PWM que controla los motores
 */
void Motor_Init()
{

    /*-------------------------Servos----------------------------------*/
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);                            // Habilita el puerto F para se�al de salida PWM,
    SysCtlPeripheralSleepEnable(SYSCTL_PERIPH_GPIOF);                       // y en bajo consumo
    SysCtlPeripheralEnable(SYSCTL_PERIPH_PWM1);                             // Habilita modulo PWM 1,
    SysCtlPeripheralSleepEnable(SYSCTL_PERIPH_PWM1);                        // y en bajo consumo
    SysCtlPWMClockSet(SYSCTL_PWMDIV_16);                                    // Establece divisor del reloj del sistema (40MHz/16=2.5MHz)

    GPIOPinConfigure(GPIO_PF2_M1PWM6);                                      // Configura el pin PF2
    GPIOPinTypePWM(GPIO_PORTF_BASE, GPIO_PIN_2);                            // como salida PWM

    GPIOPinConfigure(GPIO_PF3_M1PWM7);                                      // Configura el pin PF3
    GPIOPinTypePWM(GPIO_PORTF_BASE, GPIO_PIN_3);                            // como salida PWM

                                                                            // Configura el modo de funcionamiento del generador PWM 3,
    PWMGenConfigure(PWM1_BASE, PWM_GEN_3, PWM_GEN_MODE_DOWN);               // que contara hacia abajo
    PWMOutputState(PWM1_BASE, PWM_OUT_6_BIT, true);                         // Habilita la salida PWM 6
    PWMOutputState(PWM1_BASE, PWM_OUT_7_BIT, true);                         // Habilita la salida PWM 7
    PWMGenPeriodSet(PWM1_BASE, PWM_GEN_3, PERIOD_PWM);                      // Carga la cuenta que establece la frecuencia de la se�al PWM

    PWMPulseWidthSet(PWM1_BASE, PWM_OUT_6, PARADA_DRC);                     // Carga valor al servo derecho
    PWMPulseWidthSet(PWM1_BASE, PWM_OUT_7, PARADA_IZQ);                     // Carga valor al servo izquierdo

    PWMGenEnable(PWM1_BASE, PWM_GEN_3);                                     // Habilita el generador PWM 3
}


/**
 * Funci�n para hacer avanzar el robot
 */
void Avanzar()
{
    PWMPulseWidthSet(PWM1_BASE, PWM_OUT_6, MODO == AUTOMATICO ? ADELANTE_LENTO_DRC : ADELANTE_DRC);
    PWMPulseWidthSet(PWM1_BASE, PWM_OUT_7, MODO == AUTOMATICO ? ADELANTE_LENTO_IZQ : ADELANTE_IZQ);
}

/**
 * Funci�n para hacer retroceder el robot
 */
void Retroceder()
{
    PWMPulseWidthSet(PWM1_BASE, PWM_OUT_6, ATRAS_DRC);
    PWMPulseWidthSet(PWM1_BASE, PWM_OUT_7, ATRAS_IZQ);
}

/**
 * Funci�n para parar el robot
 */
void Parar()
{
    PWMPulseWidthSet(PWM1_BASE, PWM_OUT_6, PARADA_DRC);
    PWMPulseWidthSet(PWM1_BASE, PWM_OUT_7, PARADA_IZQ);
}

/**
 * Funci�n para girar el robot hacia la derecha
 */
void Girar_Drc()
{
    PWMPulseWidthSet(PWM1_BASE, PWM_OUT_6, ATRAS_DRC);
    PWMPulseWidthSet(PWM1_BASE, PWM_OUT_7, ADELANTE_IZQ);
}

/**
 * Funci�n para girar el robot hacia la izquierda
 */
void Girar_Izq()
{
    PWMPulseWidthSet(PWM1_BASE, PWM_OUT_6, ADELANTE_DRC);
    PWMPulseWidthSet(PWM1_BASE, PWM_OUT_7, ATRAS_IZQ);
}

/**
 * Funci�n para girar el robot hacia la derecha lentamente
 */
void GirarLento_Izq()
{
    PWMPulseWidthSet(PWM1_BASE, PWM_OUT_6, ADELANTE_LENTO_DRC);
    PWMPulseWidthSet(PWM1_BASE, PWM_OUT_7, ATRAS_LENTO_IZQ);
}

/**
 * Funci�n para girar el robot hacia la izquierda lentamente
 */
void GirarLento_Drc()
{
    PWMPulseWidthSet(PWM1_BASE, PWM_OUT_6, ATRAS_LENTO_DRC);
    PWMPulseWidthSet(PWM1_BASE, PWM_OUT_7, ADELANTE_LENTO_IZQ);
}






