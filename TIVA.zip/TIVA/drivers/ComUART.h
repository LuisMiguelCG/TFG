/**
 * Driver encargado de la comunicaci�n UART
 */

#ifndef DRIVERS_COMUART_H_
#define DRIVERS_COMUART_H_

/*********************************************************************************
*  Includes
********************************************************************************/
#include "drivers/Brujula.h"
#include "drivers/Motor.h"
#include "drivers/Navegacion.h"

/*********************************************************************************
 *  Funciones
 ********************************************************************************/
void UART2_Init(void);                                                  // Configuracion del modulo UART2.
void UART_Task(void *pvParameters);                                     // Tarea encargada de la gestion
                                                                        // de comandos recibidos.
void UART_ReciveData(uint32_t ui32UARTBase, uint8_t* dato);             // Funci�n para recibir por la UART
void UART_SendData(uint32_t ui32UARTBase, unsigned char *pui8Buffer,    // Funcion para enviar por la UART
                   uint32_t ui32Count);                                 //
void UART2IntHandler(void);                                             // Rutina de interrupcion del modulo UART2


#endif /* DRIVERS_COMUART_H_ */
