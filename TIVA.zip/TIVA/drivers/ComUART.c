/**
 * Driver encargado de la comunicaci�n UART
 */
/*********************************************************************************
*  Includes
********************************************************************************/
#include "drivers/ComUART.h"

/*********************************************************************************
* Variable Globales
********************************************************************************/
QueueHandle_t xQueueUART;
uint32_t ui32index;
bool isReset = false;

static uint32_t pwm_rd, pwm_ri;

extern rbt_modo_t MODO;
extern rbt_estado_t ESTADO;
extern rbt_estado_t ESTADO_ANT;
extern SemaphoreHandle_t SemaphoreNavegacion;
extern bool isFirstTime;
extern bool isRotating;


/*********************************************************************************
*  Prototipos
********************************************************************************/
static void _get_PWM(void);
static void _set_PWM(void);
static void _clear_Tx(void);

/*********************************************************************************
 *  Funciones
 ********************************************************************************/

/**
 * Configuraci�n del m�dulo UART2 (comunicaci�n con ESP32)
 */
void UART2_Init(void){

    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART2);
    SysCtlPeripheralSleepEnable(SYSCTL_PERIPH_UART2);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOD);
    SysCtlPeripheralSleepEnable(SYSCTL_PERIPH_GPIOD);
    GPIOUnlockPin(GPIO_PORTD_BASE, GPIO_PIN_7);
    GPIOPinConfigure(GPIO_PD6_U2RX);
    GPIOPinConfigure(GPIO_PD7_U2TX);
    GPIOPinTypeUART(GPIO_PORTD_BASE, GPIO_PIN_6 | GPIO_PIN_7);

    UARTConfigSetExpClk(UART2_BASE, SysCtlClockGet(), 115200,
                            (UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE |
                             UART_CONFIG_PAR_NONE));

    UARTFIFODisable(UART2_BASE);
    UARTIntDisable(UART2_BASE, 0xFFFFFFFF);
    UARTIntClear(UART2_BASE, UART_INT_RX | UART_INT_RT);
    UARTIntEnable(UART2_BASE, UART_INT_RX | UART_INT_RT);
    IntEnable(INT_UART2);
    UARTEnable(UART2_BASE);


    xQueueUART = xQueueCreate(8,sizeof(uint16_t));
    if(xQueueUART == NULL) while(1);

}

/**
 * Tarea encargada de la gestion de comandos recibidos
 */
void UART_Task(void *pvParameters)
{
    uint8_t cmd;
    rbt_estado_t aux;

    while(1)
    {
        xQueueReceive(xQueueUART, &cmd, portMAX_DELAY);

        switch(cmd)
        {
            case CMD_MODO_IDLE:

                Parar();
                ESTADO_ANT = ESTADO;
                ESTADO = PARADO;
                if(MODO == AUTOMATICO)
                {
                    _clear_Tx();
                    ResetMapa();
                }
                OnOffEncoders(false);
                MODO = IDLE;
                break;

            case CMD_MODO_MANUAL:

                MODO = MANUAL;
                OnOffEncoders(false);
                break;

            case CMD_MODO_AUTOMATICO:

                MODO = AUTOMATICO;
                OnOffEncoders(true);
                break;

            case CMD_PARADA:

                Parar();
                ESTADO_ANT = ESTADO;
                ESTADO = PARADO;
                break;

            case CMD_AVANCE:

                Avanzar();
                ESTADO_ANT = ESTADO;
                ESTADO = AVANZANDO;
                break;

            case CMD_RETROCESO:

                Retroceder();
                ESTADO_ANT = ESTADO;
                ESTADO = RETROCEDIENDO;
                break;

            case CMD_GIRO_D:

                Girar_Drc();
                ESTADO_ANT = ESTADO;
                ESTADO = GIRANDO;
                break;

            case CMD_GIRO_I:

                Girar_Izq();
                ESTADO_ANT = ESTADO;
                ESTADO = GIRANDO;
                break;

            case CMD_START_AUTO:

                if(isFirstTime) xSemaphoreGive(SemaphoreNavegacion);

            case CMD_STOP_AUTO:

                _get_PWM();
                Parar();
                ESTADO_ANT = ESTADO;
                ESTADO = PARADO;
                break;

            case CMD_CONTINUE_AUTO:

                aux = ESTADO_ANT;
                ESTADO_ANT = ESTADO;
                ESTADO = aux;
                _set_PWM();
                break;

            case CMD_GIRO_90D:

                Brujula_Giro90(CMD_GIRO_90D);
                break;

            case CMD_GIRO_90I:

                Brujula_Giro90(CMD_GIRO_90I);
                break;

            case CMD_RESET:

                _clear_Tx();
                if(isRotating) isReset = true;
                Parar();
                ESTADO_ANT = ESTADO;
                ESTADO = PARADO;
                ResetMapa();
                break;

        }
    }
}

/**
 * Funci�n para recibir por la UART
 */
void UART_ReciveData(uint32_t ui32UARTBase, uint8_t* dato)
{
    if(UARTCharsAvail(ui32UARTBase))
    {
        *dato = UARTCharGetNonBlocking(ui32UARTBase);
    }
}

/**
 * Funcion para enviar por la UART
 */
void UART_SendData(uint32_t ui32UARTBase, unsigned char *pui8Buffer, uint32_t ui32Count){

    for(ui32index = 0; ui32index < ui32Count; ui32index++){

        UARTCharPutNonBlocking(ui32UARTBase, *pui8Buffer++);
    }

}

/*********************************************************************************
 *  Funciones Pivadas
 ********************************************************************************/

/**
 * Funcion privada para obtener el valor del pulso de las ruedas
 */
static void _get_PWM(void)
{
    pwm_rd = PWMPulseWidthGet(PWM1_BASE, PWM_OUT_6);
    pwm_ri = PWMPulseWidthGet(PWM1_BASE, PWM_OUT_7);
}

/**
 * Funcion privada para establecer el valor del pulso de las ruedas
 */

static void _set_PWM(void)
{
    PWMPulseWidthSet(PWM1_BASE, PWM_OUT_6, pwm_rd);
    PWMPulseWidthSet(PWM1_BASE, PWM_OUT_7, pwm_ri);
}

/**
 * Funcion privada para limpiar el buffer de Tx y Rx
 */
static void _clear_Tx(void)
{
    UARTDisable(UART2_BASE);
    UARTEnable(UART2_BASE);
}

/*********************************************************************************
 *  Rutinas de Interrupcion
 ********************************************************************************/

/**
 * Rutina de interrupcion de recepcion por UART2
 */
void UART2IntHandler(void){

    BaseType_t xHigherPriorityTaskWoken = pdFALSE;
    uint32_t ui32status = UARTIntStatus(UART2_BASE, true);
    uint8_t ui8DataRx;

    if(ui32status & (UART_INT_RX | UART_INT_RT))
    {
        UART_ReciveData(UART2_BASE, &ui8DataRx);
        UARTIntClear(UART2_BASE, UART_INT_RX);
        xQueueSendFromISR(xQueueUART, &ui8DataRx, &xHigherPriorityTaskWoken);
    }

    portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
}



