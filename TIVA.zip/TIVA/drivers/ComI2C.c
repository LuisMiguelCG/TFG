/**
 * Driver encargado de la comunicacion I2C
 */

/*********************************************************************************
*  Includes
********************************************************************************/
#include "drivers/ComI2C.h"

/*********************************************************************************
 *  Funciones
 ********************************************************************************/

/**
 * Configuracion del modulo I2C1
 */
void I2C1_Init(void)
{

    SysCtlPeripheralEnable(SYSCTL_PERIPH_I2C1);
    SysCtlPeripheralSleepEnable(SYSCTL_PERIPH_I2C1);

    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
    SysCtlPeripheralSleepEnable(SYSCTL_PERIPH_GPIOA);

    GPIOPadConfigSet(GPIO_PORTA_BASE, GPIO_PIN_6|GPIO_PIN_7,
                            GPIO_STRENGTH_12MA, GPIO_PIN_TYPE_STD_WPU);

    GPIOPinConfigure(GPIO_PA6_I2C1SCL);
    GPIOPinConfigure(GPIO_PA7_I2C1SDA);

    GPIOPinTypeI2CSCL(GPIO_PORTA_BASE, GPIO_PIN_6);
    GPIOPinTypeI2C(GPIO_PORTA_BASE, GPIO_PIN_7);

    I2CMasterInitExpClk(I2C1_BASE, SysCtlClockGet(), false);

}

/**
 * Funci�n encargada de escribir en el bus I2C
 */
void I2C1_Write(uint8_t slave_addr, uint8_t reg_addr, uint8_t data)
{
    I2CMasterSlaveAddrSet(I2C1_BASE, slave_addr, false);
    I2CMasterDataPut(I2C1_BASE, reg_addr);
    I2CMasterControl(I2C1_BASE, I2C_MASTER_CMD_BURST_SEND_START);

    while (I2CMasterBusy(I2C1_BASE));

    I2CMasterDataPut(I2C1_BASE, data);
    I2CMasterControl(I2C1_BASE, I2C_MASTER_CMD_BURST_SEND_FINISH);

    while (I2CMasterBusy(I2C1_BASE));
}


/**
 * Funci�n encargada de leer en el bus I2C
 */
uint8_t I2C1_Read(uint8_t slave_addr, uint8_t reg_addr)
{
    uint8_t data;

    I2CMasterSlaveAddrSet(I2C1_BASE, slave_addr, false);
    I2CMasterDataPut(I2C1_BASE, reg_addr);
    I2CMasterControl(I2C1_BASE, I2C_MASTER_CMD_BURST_SEND_START);

    while (I2CMasterBusy(I2C1_BASE));

    I2CMasterSlaveAddrSet(I2C1_BASE, slave_addr, true);
    I2CMasterControl(I2C1_BASE, I2C_MASTER_CMD_SINGLE_RECEIVE);

    while (I2CMasterBusy(I2C1_BASE));

    data = I2CMasterDataGet(I2C1_BASE);

    return data;
}




