/**
 * Driver encargado del manejo de los sensores de distancia
 */

#ifndef DRIVERS_SENDISTANCIA_H_
#define DRIVERS_SENDISTANCIA_H_

/*********************************************************************************
*  Includes
********************************************************************************/
#include "drivers/Motor.h"

/*********************************************************************************
*  Defines
********************************************************************************/
#define INDICE_MAX          26      // Indice maximo de las listas de valores y distancia.
#define INDICE_MIN          0       // Indice minimo de las listas de valores y distancia.
#define DIST_DETECTF        10      // Distancia de deteccion del sensor frontal.
#define DIST_DETECTR        20      // Distancia de deteccion del sensor derecho.
#define DIST_DETECTL        20      // Distancia de deteccion del sensor izquierdo.



typedef struct                      // Estructura para las muestras
{                                   // despues de conversion.
    uint16_t chan1;                 // 32 bits -> 16 bit
    uint16_t chan2;                 //
    uint16_t chan3;                 //
    uint16_t chan4;                 //
} MuestrasADC;                      //

typedef struct                      // Estructura para las muestras leidas
{                                   // del ADC.
    uint32_t chan1;                 //
    uint32_t chan2;                 //
    uint32_t chan3;                 //
    uint32_t chan4;                 //
} MuestrasLeidasADC;                //

/*********************************************************************************
 *  Funciones
 ********************************************************************************/
void ADC_Init(void);                // Funcion para configurar los modulos ADC0 y ADC1.
uint8_t ReadFrontal();              // Funci�n que lee el sensor frontal.
uint8_t ReadDerecha();              // Funci�n que lee el sensor de la derecha.
uint8_t ReadIzquierda();            // Funci�n que lee el sensor de la izquierda.
void ADC_DisparaF(void);            // Provoca el disparo de una conversion (ADC0, Secuenciador 1).
void ADC_DisparaD(void);            // Provoca el disparo de una conversion (ADC1, Secuenciador 1).
void ADC_DisparaI(void);            // Provoca el disparo de una conversion (ADC0, Secuenciador 2).
void ADC_Lee(uint16_t *datos);      // Funci�n para leer los datos obtenidos del ADC.
void ADC0S1IntHandler(void);        // Rutina de interrupci�n del ADC0 Secuenciador 1.
void ADC0S2IntHandler(void);        // Rutina de interrupci�n del ADC0 Secuenciador 2.
void ADC1S1IntHandler(void);        // Rutina de interrupci�n del ADC1 Seceunciador 1.







#endif /* DRIVERS_SENDISTANCIA_H_ */
