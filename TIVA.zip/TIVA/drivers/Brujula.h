/**
 * Driver encargado de manejar el sensor br�jula
 */

#ifndef DRIVERS_BRUJULA_H_

#define DRIVERS_BRUJULA_H_

/*********************************************************************************
*  Includes
********************************************************************************/
#include "drivers/ComI2C.h"
#include "drivers/Motor.h"
#include "drivers/Navegacion.h"

/*********************************************************************************
*  Defines
********************************************************************************/
#define Brujula_ADDRESS             0x0D            // Direccion del sensor brujula
#define REGISTER_DATA_X_LSB         0x00            // Direccion del registro X parte baja
#define REGISTER_SIGNED_X_MSB       0x01            // Direccion del registro X parte alta
#define REGISTER_DATA_Y_LSB         0x02            // Direccion del registro Y parte baja
#define REGISTER_SIGNED_Y_MSB       0x03            // Direccion del registro Y parte alta
#define REGISTER_DATA_Z_LSB         0x04            // Direccion del registro Z parte baja
#define REGISTER_SIGNED_Z_MSB       0x05            // Direccion del registro Z parte alta
#define REGISTER_STATUS             0x06            // Direccion del registro de estado
#define REGISTER_TEMP_LSB           0x07            // Direccion del registro de temperatura parte baja
#define REGISTER_TEMP_MSB           0x08            // Direccion del registro de temperatura parte alta
#define REGISTER_CONTROL1           0x09            // Direccion del registro de control 1
#define REGISTER_CONTROL2           0x0A            // Direccion del registro de control 2
#define REGISTER_PERIOD             0x0B            // Direccion del registro periodo
#define DECLINACION                 0.13            // Valor declinacion malaga
#define RAD_TO_DEG                  ANG180/PI       // Factor para conversion Rad->Deg
#define DESFASE                     19              // Desfase
#define ANGULO_VARIACION            3               // Variacion angulo de 90
#define ANGULO_VARIACION180         20              // Variacion angulo de 180
#define ANG360                      360             // Angulo de 360 grados
#define ANG269                      269             // Angulo de 269 grados
#define ANG180                      180             // Angulo de 180 grados
#define ANG90                       90              // Angulo de 90 grados


/*********************************************************************************
 *  Funciones
 ********************************************************************************/
void Brujula_Init();                                        // Configuracion el sensor br�jula.
void Brujula_Giro90(uint8_t giro);                          // Funcion para realizar giros de 90 grados.
void Brujula_Giro180();                                     // Funcion para realizar giros de 180 grados.
uint16_t Brujula_CalcularGrados();                          // Funcion para calcular el angulo respecto del norte magnetico
                                                            // en funcion de las coordenadas X e Y.
void Brujula_ReadData(int16_t* x, int16_t* y, int16_t* z);  // Funci�n encargada de leer la br�jula.


#endif /* DRIVERS_BRUJULA_H_ */
