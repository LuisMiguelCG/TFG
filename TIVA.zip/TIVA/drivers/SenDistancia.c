/**
 * Driver encargado del manejo de los sensores de distancia
 */

/*********************************************************************************
*  Includes
********************************************************************************/
#include "Tiva_common.h"
#include "drivers/SenDistancia.h"

/*********************************************************************************
* Variable Globales
********************************************************************************/
QueueHandle_t xQueueADC;

uint8_t Lista_Distancia[27] = {4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19,
                               20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30};

uint16_t Lista_ADCF[27] = {3170, 2675, 2290, 2105, 1850, 1640, 1500, 1380, 1275, 1150, 1055, 985,
                            935, 880, 835, 785, 765, 710, 690, 665, 640, 620, 595, 570, 545, 520, 520};

uint16_t Lista_ADCI[27] = {3410, 2820, 2500, 2135, 1885, 1725, 1545, 1390, 1300, 1205, 1095, 995, 965,
                           855, 805, 755, 730, 685, 660, 615, 590, 570, 540, 520, 490, 465, 465};

uint16_t Lista_ADCD[27] = {3320, 2800, 2460, 2130, 1855, 1675, 1525, 1360, 1235, 1130, 1070, 990,
                            940, 890, 840, 795, 770, 725, 695, 650, 625, 605, 575, 555, 555, 555};
/*********************************************************************************
 *  Funciones privadas
 ********************************************************************************/
static uint8_t buscar_indice_medida(uint16_t *A, uint16_t val, uint8_t imin, uint8_t imax);


/*********************************************************************************
 *  Funciones
 ********************************************************************************/

/**
 * Funcion para configurar los modulos ADC0 y ADC1.
 */
void ADC_Init(void)
{
    SysCtlPeripheralEnable(SYSCTL_PERIPH_ADC0);                                 // Habilita el modulo ADC0
    SysCtlPeripheralSleepEnable(SYSCTL_PERIPH_ADC0);                            // y en bajo consumo.

    SysCtlPeripheralEnable(SYSCTL_PERIPH_ADC1);                                 // Habilita el modulo ADC1
    SysCtlPeripheralSleepEnable(SYSCTL_PERIPH_ADC1);                            // y en bajo consumo.

    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOE);                                // Habilita el puerto GPIOE
    SysCtlPeripheralSleepEnable(SYSCTL_PERIPH_GPIOE);                           // y en bajo consumo.

    GPIOPinTypeADC(GPIO_PORTE_BASE, GPIO_PIN_3 | GPIO_PIN_2 | GPIO_PIN_1);      // Configura los pines como tipo ADC

    //Configuracion  ADC0 secuenciador 1 y 2
    ADCSequenceDisable(ADC0_BASE,1);
    ADCSequenceDisable(ADC0_BASE,2);

    //Configuracion  ADC1 secuenciador 1
    ADCSequenceDisable(ADC1_BASE,1);

    //Configuramos la velocidad de conversion al maximo (1MS/s)
    ADCClockConfigSet(ADC0_BASE, ADC_CLOCK_RATE_FULL, 1);
    ADCClockConfigSet(ADC1_BASE, ADC_CLOCK_RATE_FULL, 1);

    // ADC0 Secuenciador 1
    ADCSequenceConfigure(ADC0_BASE,1,ADC_TRIGGER_PROCESSOR,0);                      // Disparo software (processor trigger)
    ADCSequenceStepConfigure(ADC0_BASE,1,0,ADC_CTL_CH0);                            // Configura el paso de cuatro muestras
    ADCSequenceStepConfigure(ADC0_BASE,1,1,ADC_CTL_CH0);                            //
    ADCSequenceStepConfigure(ADC0_BASE,1,2,ADC_CTL_CH0);                            //
    ADCSequenceStepConfigure(ADC0_BASE,1,3,ADC_CTL_CH0|ADC_CTL_IE |ADC_CTL_END );   // y la ultima muestra genera la interrupcion
    ADCSequenceEnable(ADC0_BASE,1);                                                 // Habilita la secuencia

    //Habilita las interrupciones
    ADCIntClear(ADC0_BASE,1);                                           // Limpia las interrupciones del secuenciador 1 del modulo ADC0
    ADCIntEnable(ADC0_BASE,1);                                          // Habilita las interrupciones del secuenciador 1 del modulo ADC0
    IntPrioritySet(INT_ADC0SS1, configMAX_SYSCALL_INTERRUPT_PRIORITY);  // Carga la prioridad del la interrucion del secuenciador 1 del modulo ADC0
    IntEnable(INT_ADC0SS1);                                             // Habilita la interrupcion del secuenciador 1 del modulo ADC0

    // ADC0 Secuenciador 2
    ADCSequenceConfigure(ADC0_BASE,2,ADC_TRIGGER_PROCESSOR,0);                      // Disparo software (processor trigger)
    ADCSequenceStepConfigure(ADC0_BASE,2,0,ADC_CTL_CH1);                            // Configura el paso de cuatro muestras
    ADCSequenceStepConfigure(ADC0_BASE,2,1,ADC_CTL_CH1);                            //
    ADCSequenceStepConfigure(ADC0_BASE,2,2,ADC_CTL_CH1);                            //
    ADCSequenceStepConfigure(ADC0_BASE,2,3,ADC_CTL_CH1 |ADC_CTL_IE |ADC_CTL_END );  // y la ultima muestra genrea la interrupcion
    ADCSequenceEnable(ADC0_BASE,2);                                                 // Habilita la secuencia

    //Habilita las interrupciones
    ADCIntClear(ADC0_BASE,2);                                           // Limpia las interrupciones del secuenciador 2 del modulo ADC0
    ADCIntEnable(ADC0_BASE,2);                                          // Habilita las interrupciones del secuenciador 2 del modulo ADC0
    IntPrioritySet(INT_ADC0SS2, configMAX_SYSCALL_INTERRUPT_PRIORITY);  // Carga la prioridad del la interrucion del secuenciador 2 del modulo ADC0
    IntEnable(INT_ADC0SS2);                                             // Habilita la interrupcion del secuenciador 1 del modulo ADC0

    // ADC1 Secuenciador 1
    ADCSequenceConfigure(ADC1_BASE,1,ADC_TRIGGER_PROCESSOR,0);                      // Disparo software (processor trigger)
    ADCSequenceStepConfigure(ADC1_BASE,1,0,ADC_CTL_CH2);                            // Configura el paso de cuatro muestras
    ADCSequenceStepConfigure(ADC1_BASE,1,1,ADC_CTL_CH2);                            //
    ADCSequenceStepConfigure(ADC1_BASE,1,2,ADC_CTL_CH2);                            //
    ADCSequenceStepConfigure(ADC1_BASE,1,3,ADC_CTL_CH2 |ADC_CTL_IE |ADC_CTL_END );  // y la ultima muestra genrea la interrupcion
    ADCSequenceEnable(ADC1_BASE,1);                                                 // Habilita la secuencia

    //Habilita las interrupciones
    ADCIntClear(ADC1_BASE,1);                                           // Limpia las interrupciones del secuenciador 1 del modulo ADC1
    ADCIntEnable(ADC1_BASE,1);                                          // Habilita las interrupciones del secuenciador 1 del modulo ADC1
    IntPrioritySet(INT_ADC1SS1, configMAX_SYSCALL_INTERRUPT_PRIORITY);  // Carga la prioridad del la interrucion del secuenciador 1 del modulo ADC1
    IntEnable(INT_ADC1SS1);                                             // Habilita la interrupcion del secuenciador 1 del modulo ADC1

    //Creamos una cola de mensajes para la comunicacion entre la ISR y la tara que llame a configADC_LeeADC(...)
    xQueueADC=xQueueCreate(8,sizeof(uint16_t));
    if (xQueueADC==NULL)
    {
        while(1);
    }
}

/**
 * Funci�n que lee el sensor frontal.
 * @return 1-> Hay pared, 0-> No hay pared
 */
uint8_t ReadFrontal()
{
    uint16_t ValoresF;
    uint8_t i;

    ADC_DisparaF();
    ADC_Lee(&ValoresF);

    i = buscar_indice_medida(Lista_ADCF, ValoresF, INDICE_MIN, INDICE_MAX);

    return (Lista_Distancia[i] <= DIST_DETECTF || ValoresF > Lista_ADCF[INDICE_MIN]) ? 1 : 0;

}

/**
 * Funci�n que lee el sensor de la derecha.
 * @return 1-> Hay pared, 0-> No hay pared
 */
uint8_t ReadDerecha()
{
    uint16_t ValoresD;
    uint8_t i;

    ADC_DisparaD();
    ADC_Lee(&ValoresD);

    i = buscar_indice_medida(Lista_ADCD, ValoresD, INDICE_MIN, INDICE_MAX);

    return (Lista_Distancia[i] <= DIST_DETECTR || ValoresD > Lista_ADCD[INDICE_MIN]) ? 1 : 0;

}

/**
 * Funci�n que lee el sensor de la izquierda.
 * @return 1-> Hay pared, 0-> No hay pared
 */
uint8_t ReadIzquierda()
{
    uint16_t ValoresI;
    uint8_t i;

    ADC_DisparaI();
    ADC_Lee(&ValoresI);

    i = buscar_indice_medida(Lista_ADCI, ValoresI, INDICE_MIN, INDICE_MAX);

    return (Lista_Distancia[i] <= DIST_DETECTL || ValoresI > Lista_ADCI[INDICE_MIN]) ? 1 : 0;
}


/**
 * Provoca el disparo de una conversion (ADC0, Secuenciador 1).
 */
void ADC_DisparaF(void)
{
    ADCProcessorTrigger(ADC0_BASE,1);
}

/**
 * Provoca el disparo de una conversion (ADC1, Secuenciador 1).
 */
void ADC_DisparaD(void)
{
    ADCProcessorTrigger(ADC1_BASE,1);
}

/**
 * Provoca el disparo de una conversion (ADC0, Secuenciador 2).
 */
void ADC_DisparaI(void)
{
    ADCProcessorTrigger(ADC0_BASE,2);
}


/**
 * Funci�n para leer los datos obtenidos del ADC.
 */
void ADC_Lee(uint16_t *datos)
{
    xQueueReceive(xQueueADC,datos,portMAX_DELAY);
}


/**
 * Funcion que indica la poscion mas cercana del valor recibido por el ADC en el array definido.
 */
static uint8_t buscar_indice_medida(uint16_t *A, uint16_t val, uint8_t imin, uint8_t imax)
{
  uint8_t imid;

  while (imin < imax)
    {
      imid= (imin+imax)>>1;

      if (A[imid] > val)
        imin = imid + 1;
      else
        imax = imid;
    }
    return imax;
}

/*********************************************************************************
 *  Rutinas de Interrupcion
 ********************************************************************************/

/**
 * Rutina de interrupci�n del ADC0 Secuenciador 1.
 */
void ADC0S1IntHandler(void)
{
    portBASE_TYPE higherPriorityTaskWoken=pdFALSE;

    MuestrasLeidasADC Leidas_SenM;
    MuestrasADC Finales_SenM;
    uint16_t Media_SenM;

    ADCIntClear(ADC0_BASE,1);
    ADCSequenceDataGet(ADC0_BASE,1,(uint32_t *)&Leidas_SenM);

    //Pasamos de 32 bits a 16 (el conversor es de 12 bits, as� que s�lo son significativos los bits del 0 al 11)
    Finales_SenM.chan1=Leidas_SenM.chan1;
    Finales_SenM.chan2=Leidas_SenM.chan2;
    Finales_SenM.chan3=Leidas_SenM.chan3;
    Finales_SenM.chan4=Leidas_SenM.chan4;

    Media_SenM = (Finales_SenM.chan1 + Finales_SenM.chan2 + Finales_SenM.chan3 + Finales_SenM.chan4)/4;

    //Guardamos en la cola
    xQueueSendFromISR(xQueueADC,&Media_SenM,&higherPriorityTaskWoken);
    portEND_SWITCHING_ISR(higherPriorityTaskWoken);
}

/**
 * Rutina de interrupci�n del ADC0 Secuenciador 2.
 */
void ADC0S2IntHandler(void)
{
    portBASE_TYPE higherPriorityTaskWoken=pdFALSE;

    MuestrasLeidasADC Leidas_SenM;
    MuestrasADC Finales_SenM;
    uint16_t Media_SenM;

    ADCIntClear(ADC0_BASE,2);
    ADCSequenceDataGet(ADC0_BASE,2,(uint32_t *)&Leidas_SenM);

    //Pasamos de 32 bits a 16 (el conversor es de 12 bits, as� que s�lo son significativos los bits del 0 al 11)
    Finales_SenM.chan1=Leidas_SenM.chan1;
    Finales_SenM.chan2=Leidas_SenM.chan2;
    Finales_SenM.chan3=Leidas_SenM.chan3;
    Finales_SenM.chan4=Leidas_SenM.chan4;

    Media_SenM = (Finales_SenM.chan1 + Finales_SenM.chan2 + Finales_SenM.chan3 + Finales_SenM.chan4)/4;

    //Guardamos en la cola
    xQueueSendFromISR(xQueueADC,&Media_SenM,&higherPriorityTaskWoken);
    portEND_SWITCHING_ISR(higherPriorityTaskWoken);
}

/**
 * Rutina de interrupci�n del ADC1 Seceunciador 1.
 */
void ADC1S1IntHandler(void)
{
    portBASE_TYPE higherPriorityTaskWoken=pdFALSE;

    MuestrasLeidasADC Leidas_SenM;
    MuestrasADC Finales_SenM;
    uint16_t Media_SenM;

    ADCIntClear(ADC1_BASE,1);
    ADCSequenceDataGet(ADC1_BASE,1,(uint32_t *)&Leidas_SenM);

    //Pasamos de 32 bits a 16 (el conversor es de 12 bits, as� que s�lo son significativos los bits del 0 al 11)
    Finales_SenM.chan1=Leidas_SenM.chan1;
    Finales_SenM.chan2=Leidas_SenM.chan2;
    Finales_SenM.chan3=Leidas_SenM.chan3;
    Finales_SenM.chan4=Leidas_SenM.chan4;

    Media_SenM = (Finales_SenM.chan1 + Finales_SenM.chan2 + Finales_SenM.chan3 + Finales_SenM.chan4)/4;

    //Guardamos en la cola
    xQueueSendFromISR(xQueueADC,&Media_SenM,&higherPriorityTaskWoken);
    portEND_SWITCHING_ISR(higherPriorityTaskWoken);
}
