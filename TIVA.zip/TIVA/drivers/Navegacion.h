/**
 * Driver encagardo de gestionar la navegaci�n del robot en el laberinto.
 */

#ifndef DRIVERS_NAVEGACION_H_
#define DRIVERS_NAVEGACION_H_

/*********************************************************************************
*  Includes
********************************************************************************/
#include "Tiva_common.h"
#include "drivers/SenDistancia.h"
#include "drivers/Motor.h"
#include "drivers/Brujula.h"
#include "drivers/ComUART.h"

/*********************************************************************************
*  Defines
********************************************************************************/
#define MAPA_SIZE   21                      // Tama�o del mapa 21x21.
#define MSG_SIZE    13                      // Tama�o del mensaje.
#define DISTANCIA   20                      // Distancia en cm que recorre el robot para recoger informacion.
#define R           3.5                     // Radio de la rueda en cm
#define N_GIROS     11                      // N� giros para la distancia deseada.
                                            // Calculados: (12*DISTANCIA)/(2*PI*R)
#define CENTRO      10                      // Posicion del centro (10,10).

#define ENCODER_I    GPIO_PIN_4             // Etiqueta con el pin del sensor encoder.
#define SENSOR_BAJO  GPIO_PIN_6             // Etiqueta con el pin del sensor bajo.

typedef enum                                // Tipo de dato para referirse
{                                           // al estado de las celdas
    DESCONOCIDO,                            // en las que se divide
    CONOCIDO,                               // el mapa.
    X                                       //
                                            //
}EstadoCelda_t;                             //

typedef enum                                // Tipo de dato para referirse
{                                           // a la existencia de pared o no.
    NO_PARED,                               //
    PARED                                   //
                                            //
}Pared_t;                                   //

typedef enum                                // Tipo de dato para referirse
{                                           // al sentido de movimiento.
    NEGATIVO,                               //
    POSITIVO                                //
                                            //
}Sentido_t;                                 //

typedef enum                                // Tipo de dato para referirse
{                                           // al eje de movimiento.
    HORIZONTAL,                             //
    VERTICAL                                //
                                            //
}Eje_t;                                     //

typedef struct                              // Estructura para referirse
{                                           // a la orientacion del microbot
    Sentido_t sentido;                      // dentro del laberinto.
    Eje_t   eje;                            //
                                            //
}Orientacion_t;                             //

typedef struct                              // Estructura para referirse
{                                           // a las paredes del laberinto.
    Pared_t d;                              //
    Pared_t i;                              //
    Pared_t f;                              //
                                            //
}Paredes_t;                                 //

typedef struct                              // Estructura que engloba toda
{                                           // la informacion referente a
    int8_t x;                               // la posicion del microbot
    int8_t y;                               // dentro del laberinto.
    Orientacion_t orientacion;              //
    Paredes_t paredes;                      //
    EstadoCelda_t estado;                   //
}InfoPosicion_t;                            //


/*********************************************************************************
 *  Funciones
 ********************************************************************************/
void NavegacionInit();                      // Funci�n para configurar el encoder y sensor bajo e
                                            // inicializar el mapa y la posicion del robot en el mapa.
void ResetMapa();                           // Funcion para resetar el mapa y restrablecer los valor de inicio.
void ActualizarMapa();                      // Funcion encargada de actulizar el mapa con la posicion del robot
                                            // y la informacion recogida por este.
void ActualizarPosicion();                  // Funcion encargada de actualizar la posicion del robot.
void Navegacion_Task(void *pvParameters);   // Tarea encargada de la navegacion del robot en el laberinto.
void Enviar_mensaje();                      // Funcion encargada de construir y enviar el mensaje por la UART.
void Decidir_Movimiento();                  // Funcion encargada de decidir el proximo movimiento.
void OnOffEncoders(bool on_off);            // Funcion para habilitar o deshabilitar el encoder.
void GPIOBIntHandle(void);                  // Rutina encargada de las interruciones del encoder, sensor_bajo.



#endif /* DRIVERS_NAVEGACION_H_ */
