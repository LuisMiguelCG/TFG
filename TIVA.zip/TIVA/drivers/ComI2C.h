/**
 * Driver encargado de la comunicacion I2C
 */

#ifndef DRIVERS_COMI2C_H_
#define DRIVERS_COMI2C_H_

/*********************************************************************************
*  Includes
********************************************************************************/
#include "Tiva_common.h"

/*********************************************************************************
 *  Funciones
 ********************************************************************************/
void I2C1_Init(void);                                                    // Configuracion del modulo I2C1
void I2C1_Write(uint8_t slave_addr, uint8_t reg_addr, uint8_t data);     // Funci�n encargada de escribir en el bus I2C
uint8_t I2C1_Read(uint8_t slave_addr, uint8_t reg_addr);                 // Funci�n encargada de leer en el bus I2C



#endif /* DRIVERS_COMI2C_H_ */
