/**
 * Driver encargado de manejar el sensor br�jula
 */

/*********************************************************************************
*  Includes
********************************************************************************/
#include "Tiva_common.h"
#include "drivers/Brujula.h"

/*********************************************************************************
* Variable Globales
********************************************************************************/
bool isRotating = false;                // Variable para indicar que esta girando

extern rbt_modo_t MODO;                 // Modo de funcionamiento del robot
extern rbt_estado_t ESTADO;              // Estado actual del robot
extern rbt_estado_t ESTADO_ANT;          // Estado anterior del robot
extern bool isReset;                    // Variable que indica si se ha realizado un reset

/*********************************************************************************
 *  Funciones
 ********************************************************************************/

/**
 * Configuracion el sensor br�jula.
 */
void Brujula_Init()
{
    uint8_t config;

    config = 0x01;                                              // Registro control de tiempo de operaciones
    I2C1_Write(Brujula_ADDRESS, REGISTER_PERIOD, config);        // SET/RESET recomendado por fabricante que sea 0x01.
    config = 0x1D;                                              // Modo de operacion continuo.
    I2C1_Write(Brujula_ADDRESS, REGISTER_CONTROL1, config);      // Frecuencia salida de datos 200 Hz.
                                                                // Rango del sensor magnetico 8 G.
                                                                // Ancho de banda 512.
}

/**
 * Funcion para realizar giros de 90 grados.
 */
void Brujula_Giro90(uint8_t giro)
{
    int16_t gradI, gradF, gradA;

    gradI = Brujula_CalcularGrados();
    OnOffEncoders(false);

    switch(giro)
    {
        case CMD_GIRO_90D:

            gradF = fmod(gradI + ANG90, ANG360);
            gradA = gradI;
            GirarLento_Drc();
            ESTADO_ANT = ESTADO;
            ESTADO = GIRANDO;
            isRotating = true;

            while(1)
            {
                if(MODO == IDLE || isReset) break;
                gradA = Brujula_CalcularGrados();

                if(gradI <= ANG269)
                {
                    if (((gradA >= gradI) && gradA <= gradF))
                    {
                        if ((gradA - gradI >= ANG90 - ANGULO_VARIACION))
                        {
                            Parar();
                            break;
                        }
                    }
                }
                else
                {
                    if ((gradA >= gradI || gradA <= gradF))
                    {
                        if ((((gradA >= gradI) && (gradA - gradI >= ANG90 - ANGULO_VARIACION)) ||
                            ((gradA < gradI) && (ANG360 - gradI + gradA) >= ANG90 - ANGULO_VARIACION)))
                        {
                            Parar();
                            break;
                        }
                    }
                }
            }
            ESTADO_ANT = ESTADO;
            ESTADO = PARADO;
            isRotating = false;
            break;

        case CMD_GIRO_90I:

            gradF = fmod(gradI - ANG90 + ANG360, ANG360);
            gradA = gradI;
            GirarLento_Izq();
            ESTADO_ANT = ESTADO;
            ESTADO = GIRANDO;
            isRotating = true;

            while(1)
            {
                if(MODO == IDLE || isReset) break;
                gradA = Brujula_CalcularGrados();

                if(gradI >= ANG90)
                {
                    if(gradA <= gradI  &&  gradA >=  gradF)
                    {
                        if(((gradI - gradA) >= ANG90 - ANGULO_VARIACION))
                        {
                            Parar();
                            break;
                        }
                    }
                }
                else
                {
                    if(gradA <=  gradI  ||  gradA >= gradF)
                    {
                        if((((gradI >= gradA)  && (gradI - gradA) >= ANG90 - ANGULO_VARIACION) ||
                           ((gradI < gradA)  && (ANG360 - gradA + gradI) >= ANG90 - ANGULO_VARIACION)))
                        {
                            Parar();
                            break;
                        }
                    }
                }
            }
            ESTADO_ANT = ESTADO;
            ESTADO = PARADO;
            isRotating = false;
            break;
    }

    OnOffEncoders(MODO == AUTOMATICO ? true : false);
}

/**
 * Funcion para realizar giros de 180 grados.
 */
void Brujula_Giro180()
{
    int16_t gradI, gradF, gradA;

    gradI = Brujula_CalcularGrados();
    gradF = fmod(gradI + ANG180, ANG360);

    ESTADO_ANT = ESTADO;
    ESTADO = GIRANDO;
    isRotating = true;

    while (1)
    {
        if(MODO == IDLE || isReset) break;
        gradA = Brujula_CalcularGrados();
        int16_t gradD = gradF - gradA;

        if (gradD > ANG180)
        {
            gradD -= ANG360;
        }
        else if (gradD < -ANG180)
        {
            gradD += ANG360;
        }
        if (fabs(gradD) <= ANGULO_VARIACION180)
        {
            Parar();
            break;
        }
        if (gradD > 0)
        {
            GirarLento_Drc();
        }
        else
        {
            GirarLento_Izq();
        }
    }
    ESTADO_ANT = ESTADO;
    ESTADO = PARADO;
    isRotating = false;
}

/**
 * Funci�n encargada de leer la br�jula.
 */
void Brujula_ReadData(int16_t* x, int16_t* y, int16_t* z) {

    uint8_t x_lsb = I2C1_Read(Brujula_ADDRESS, REGISTER_DATA_X_LSB);
    uint8_t x_msb = I2C1_Read(Brujula_ADDRESS, REGISTER_SIGNED_X_MSB);
    uint8_t y_lsb = I2C1_Read(Brujula_ADDRESS, REGISTER_DATA_Y_LSB);
    uint8_t y_msb = I2C1_Read(Brujula_ADDRESS, REGISTER_SIGNED_Y_MSB);
    uint8_t z_lsb = I2C1_Read(0x0D, 0x04);
    uint8_t z_msb = I2C1_Read(0x0D, 0x05);

    *x = ((x_msb << 8) | x_lsb) | (1 << 16);
    *y = (y_msb << 8) | y_lsb;
    *z = (z_msb << 8) | z_lsb;

}

/**
 * Funcion para calcular el angulo respecto del norte magnetico
 * en funcion de las coordenadas X e Y.
 */
uint16_t Brujula_CalcularGrados()
{
    int16_t x, y, z;
    uint8_t i;
    float angulo = 0;

    for(i=0; i<10; ++i)
    {
        Brujula_ReadData(&x, &y, &z);

        float angulo_rad = atan2(x,y);
        float angulo_deg = angulo_rad * (ANG180 / M_PI);
        angulo_deg = angulo_deg - DECLINACION;
        angulo_deg = ANG360 - angulo_deg - DESFASE;

        if (angulo_deg < 0)
        {
            angulo_deg += ANG360;
        }
        else if (angulo_deg >= ANG360)
        {
            angulo_deg -= ANG360;
        }

       angulo = angulo + angulo_deg;
    }

    return (uint16_t)angulo/10;
}

