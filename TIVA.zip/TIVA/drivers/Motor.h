/*
 * Driver encargado de controlar los motores del robot
 */

#ifndef DRIVERS_MOTOR_H_
#define DRIVERS_MOTOR_H_


/*********************************************************************************
 *  Defines
 ********************************************************************************/
#define PERIOD_PWM              50000           // Ciclos de reloj para conseguir una se�al peri�dica de 50Hz
                                                // (seg�n reloj de perif�rico usado)

// Rueda Derecha       (PWM_OUT_6)              // Anchos de pulso en ticks de reloj del modulo PWM
#define ADELANTE_DRC            3400            // para seleccionar el movimento de la rueda derecha
#define ATRAS_DRC               4065            // conectada al motor.
#define PARADA_DRC              3800            //
#define ADELANTE_LENTO_DRC      3560            //
#define ATRAS_LENTO_DRC         3980            //

// Rueda Izquierda     (PWM_OUT_7)              // Anchos de pulso en ticks de reloj del modulo PWM
#define ADELANTE_IZQ            4075            // para seleccionar el movimento de la rueda izquierda
#define ATRAS_IZQ               3400            // conectada al motor.
#define PARADA_IZQ              3830            //
#define ADELANTE_LENTO_IZQ      3970            //
#define ATRAS_LENTO_IZQ         3575            //

/*********************************************************************************
 *  Funciones
 ********************************************************************************/
void Motor_Init();          // Funci�n para configurar el modulo PWM que controla los motores
void Avanzar();             // Funci�n para hacer avanzar el robot
void Retroceder();          // Funci�n para hacer retroceder el robot
void Parar();               // Funci�n para parar el robot
void Girar_Drc();           // Funci�n para girar el robot hacia la derecha
void Girar_Izq();           // Funci�n para girar el robot hacia la izquierda
void GirarLento_Izq();      // Funci�n para girar el robot hacia la derecha lentamente
void GirarLento_Drc();      // Funci�n para girar el robot hacia la izquierda lentamente


#endif /* DRIVERS_MOTOR_H_ */
